Experimental STM32F7 GPS disciplined Frequency Counter

Built for STM32F746 Discovery

Connect GPS to UART6

GPS TX -> UART RX PC7 (D0)
GPS RX -> UART TX PC6 (D1)
GPS PPS -> PA0 (A0)

External Signal on PA15 (D9) (observe 3.3V max)

